### v3.7 - 2024.12.15
* First version